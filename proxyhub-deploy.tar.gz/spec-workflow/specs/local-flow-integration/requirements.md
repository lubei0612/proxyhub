# Requirements Document

## Introduction

本规格说明旨在建立 ProxyHub 的完整本地测试流程，确保在不对接真实 985Proxy API 的情况下，整个系统的数据流转、余额扣除、订单管理等核心功能能够正常运行。这将为后续的真实 API 对接和生产环境部署奠定坚实基础。

## Alignment with Product Vision

ProxyHub 的核心价值是为用户提供便捷、可靠的代理 IP 管理服务。本规格通过建立完整的本地测试环境，确保以下产品愿景得以实现：
- 用户能够流畅地购买和管理代理 IP
- 系统能够准确记录所有交易和余额变动
- 管理员能够有效地管理用户和订单
- 各功能模块之间数据一致、联通无误

## Requirements

### Requirement 1: 用户余额管理与扣费

**User Story:** 作为用户，我希望购买代理 IP 时系统能够准确扣除我的账户余额，这样我可以清楚地了解我的消费情况。

#### Acceptance Criteria

1. WHEN 用户购买静态代理 IP THEN 系统 SHALL 从用户余额中扣除相应金额
2. WHEN 用户余额不足 THEN 系统 SHALL 阻止购买并提示余额不足
3. WHEN 购买成功后 THEN 用户钱包页面、账户中心、导航栏余额显示 SHALL 实时更新
4. WHEN 购买完成 THEN 系统 SHALL 创建交易记录（transaction）记录扣费详情
5. IF 购买过程中发生错误 THEN 系统 SHALL 回滚余额扣除操作

### Requirement 2: 订单创建与管理

**User Story:** 作为用户和管理员，我希望每次购买都能生成完整的订单记录，这样可以追溯和管理所有交易。

#### Acceptance Criteria

1. WHEN 用户购买代理 IP THEN 系统 SHALL 创建订单记录（order）包含订单号、用户ID、购买详情、金额、状态
2. WHEN 订单创建成功 THEN 订单 SHALL 在用户的"我的订单"页面显示
3. WHEN 订单创建成功 THEN 订单 SHALL 在管理后台的"订单管理"页面显示
4. WHEN 管理员访问订单管理 THEN 系统 SHALL 显示所有用户的订单列表，包含筛选和搜索功能
5. WHEN 订单状态变更 THEN 系统 SHALL 更新订单状态并记录变更时间

### Requirement 3: 静态代理 IP 分配与管理

**User Story:** 作为用户，我希望购买后能立即获得可用的代理 IP，并能在我的 IP 列表中查看和管理它们。

#### Acceptance Criteria

1. WHEN 用户购买静态代理 IP THEN 系统 SHALL 生成符合要求的 IP 数据（IP地址、端口、用户名、密码、国家、城市、过期时间）
2. WHEN IP 生成成功 THEN IP SHALL 保存到 static_proxies 表中，关联到购买用户
3. WHEN 购买完成 THEN 用户 SHALL 能在"我的IP"页面查看新购买的 IP
4. WHEN IP 状态为 active THEN 用户 SHALL 能看到完整的连接信息
5. WHEN IP 过期 THEN 系统 SHALL 自动更新 IP 状态为 expired

### Requirement 4: 各页面数据联通与一致性

**User Story:** 作为用户和管理员，我希望在不同页面看到的数据是一致的，操作后各相关页面都能实时更新。

#### Acceptance Criteria

1. WHEN 用户购买 IP THEN 以下页面数据 SHALL 同步更新：
   - 用户钱包余额（导航栏、钱包页面、账户中心）
   - 我的订单列表
   - 我的 IP 列表
   - 交易记录列表
   - 管理后台订单管理
   - 管理后台用户管理（用户余额）
2. WHEN 管理员审核充值 THEN 用户余额 SHALL 在所有相关页面更新
3. WHEN 数据更新失败 THEN 系统 SHALL 显示错误信息并保持数据一致性

### Requirement 5: 管理后台功能完善

**User Story:** 作为管理员，我希望能够全面管理用户、订单、充值审核和系统设置，确保平台正常运营。

#### Acceptance Criteria

1. WHEN 管理员访问"用户管理" THEN 系统 SHALL 显示所有用户列表，包含余额、状态、注册时间等信息
2. WHEN 管理员访问"订单管理" THEN 系统 SHALL 显示所有订单，支持按状态、用户、时间筛选
3. WHEN 管理员访问"充值审核" THEN 系统 SHALL 显示待审核充值申请列表
4. WHEN 管理员审核充值通过 THEN 系统 SHALL 增加用户余额并创建交易记录
5. WHEN 管理员访问"价格覆盖管理" THEN 页面 SHALL 正常显示，不出现错误
6. WHEN 管理员点击仪表盘的"充值审核"链接 THEN 系统 SHALL 正确跳转到充值审核页面，不出现 404

### Requirement 6: 前端页面修复

**User Story:** 作为用户和管理员，我希望所有页面都能正常访问，不出现空白页或加载错误。

#### Acceptance Criteria

1. WHEN 用户登录成功 THEN 系统 SHALL 正确跳转到仪表盘页面
2. WHEN 用户访问注册页面 THEN 页面 SHALL 正常显示注册表单
3. WHEN 管理员访问"价格覆盖管理" THEN 页面 SHALL 使用正确的组件显示国旗图标，不直接引用缺失的 SVG 文件
4. WHEN 用户在管理后台点击侧边栏菜单项 THEN 页面 SHALL 正确切换，不出现导航卡住的情况
5. WHEN 页面加载失败 THEN 系统 SHALL 显示友好的错误提示

## Non-Functional Requirements

### Code Architecture and Modularity
- **Single Responsibility Principle**: 每个服务方法只负责单一功能，购买流程拆分为验证、扣费、创建订单、分配 IP 等独立步骤
- **Modular Design**: 前端组件高度模块化，后端服务遵循 NestJS 模块化架构
- **Dependency Management**: 使用依赖注入管理服务依赖，避免循环依赖
- **Clear Interfaces**: 前后端通过明确的 API 接口通信，使用 DTO 进行数据传输

### Performance
- 购买流程应在 3 秒内完成
- 页面数据更新应在 1 秒内反映到所有相关页面
- 管理后台列表查询支持分页，单页不超过 50 条记录

### Security
- 所有 API 调用需要 JWT 身份验证
- 管理员操作需要额外的角色权限验证
- 敏感数据（如代理密码）需要加密存储
- 防止 SQL 注入和 XSS 攻击

### Reliability
- 购买流程使用数据库事务确保数据一致性
- 系统错误时能够回滚所有相关操作
- 所有关键操作记录详细日志便于追踪和调试

### Usability
- 所有操作提供清晰的成功/失败反馈
- 错误信息友好且具有指导性
- 页面加载显示加载动画
- 操作按钮在处理过程中禁用，防止重复提交

