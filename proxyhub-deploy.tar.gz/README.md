# ProxyHub - 智能代理管理平台

## 📋 项目概述

ProxyHub是一个全功能的代理IP管理平台，集成985Proxy服务，提供静态住宅代理、动态住宅代理管理等功能。

**当前版本**: v1.0.0  
**最后更新**: 2025-11-06

---

## 🚀 快速开始

### 环境要求
- Node.js >= 18.x
- PostgreSQL >= 14.x
- Redis >= 6.x (可选，用于订单队列)
- npm >= 9.x

### 安装步骤

1. **克隆项目**
```bash
git clone https://github.com/lubei0612/proxyhub.git
cd proxyhub
```

2. **安装依赖**
```bash
# 后端
cd backend
npm install

# 前端
cd ../frontend
npm install
```

3. **配置环境变量**
```bash
# 复制环境变量模板
cp backend/.env.example backend/.env

# 编辑.env文件，配置数据库和985Proxy API密钥
```

4. **初始化数据库**
```bash
cd backend
npm run migration:run
npm run seed:run
```

5. **启动服务**
```bash
# 后端 (http://localhost:3000)
cd backend
npm run start:dev

# 前端 (http://localhost:8080)
cd frontend
npm run dev
```

---

## 📁 项目结构

```
proxyhub/
├── backend/                 # NestJS后端
│   ├── src/
│   │   ├── modules/         # 功能模块
│   │   │   ├── auth/        # 认证模块
│   │   │   ├── user/        # 用户管理
│   │   │   ├── proxy/       # 代理管理
│   │   │   ├── proxy985/    # 985Proxy集成
│   │   │   ├── order/       # 订单管理
│   │   │   ├── billing/     # 账单管理
│   │   │   ├── pricing/     # 价格管理
│   │   │   ├── dashboard/   # 仪表盘
│   │   │   ├── admin/       # 管理后台
│   │   │   └── ...
│   │   ├── common/          # 通用组件
│   │   ├── config/          # 配置文件
│   │   └── database/        # 数据库迁移和种子
│   └── package.json
├── frontend/                # Vue 3前端
│   ├── src/
│   │   ├── views/           # 页面组件
│   │   ├── components/      # 通用组件
│   │   ├── api/             # API接口
│   │   ├── router/          # 路由配置
│   │   ├── stores/          # Pinia状态管理
│   │   └── locales/         # 国际化
│   └── package.json
├── docs/                    # 项目文档
├── docs-archive/            # 历史文档归档
├── scripts/                 # 工具脚本
└── README.md
```

---

## 🔑 默认账户

### 管理员账户
- 邮箱: `admin@example.com`
- 密码: `Admin123456!`

### 测试用户账户
- 邮箱: `user@example.com`
- 密码: `User123456!`

---

## 📊 核心功能

### ✅ 已完成功能

#### 用户功能
- [x] 用户注册/登录/登出
- [x] JWT认证
- [x] 个人资料管理
- [x] 密码修改
- [x] API密钥生成

#### 代理管理
- [x] 静态住宅代理购买
- [x] 静态代理IP列表查看
- [x] IP续费功能
- [x] IP释放
- [x] 自动续费设置
- [x] 代理使用统计

#### 账单系统
- [x] 账户余额管理
- [x] 充值申请
- [x] 充值审核（管理员）
- [x] 交易记录查询
- [x] 账单明细导出

#### 订单系统
- [x] 订单创建
- [x] 订单状态跟踪
- [x] 订单历史查询
- [x] 订单取消

#### 管理后台
- [x] 用户管理
- [x] 订单管理
- [x] 充值审核
- [x] 系统统计
- [x] 事件日志
- [x] 价格覆盖管理

#### 985Proxy集成
- [x] 库存查询
- [x] 价格计算
- [x] 静态IP购买
- [x] IP续费
- [x] 我的IP列表查询
- [x] 订单状态查询

---

### 🚧 进行中的功能

根据spec-workflow任务列表：

#### P0 - 严重问题
- [ ] IP续费API完整测试（Task 1）
- [x] 管理后台路由修复（Task 2） - 部分完成
- [ ] 管理后台数据显示修复

#### P1 - 重要功能
- [ ] 订单状态轮询机制（Task 3）
- [ ] 价格显示一致性（Task 4）
- [ ] 实时价格集成985Proxy API

#### P2 - 优化项
- [ ] 代码优化和重构（Task 5）
- [ ] 性能优化
- [ ] Docker部署优化

---

## 🛠️ 技术栈

### 后端
- **框架**: NestJS 10.x
- **数据库**: PostgreSQL 14.x + TypeORM
- **认证**: JWT + Passport
- **缓存**: Redis (可选)
- **队列**: Bull (可选)
- **文档**: Swagger/OpenAPI

### 前端
- **框架**: Vue 3 + TypeScript
- **UI库**: Element Plus
- **状态管理**: Pinia
- **路由**: Vue Router 4
- **HTTP**: Axios
- **图表**: ECharts
- **国际化**: Vue I18n

---

## 🔧 开发指南

### 代码规范
- 使用TypeScript严格模式
- 遵循ESLint规则
- 使用Prettier格式化代码
- Git提交遵循Conventional Commits

### API开发流程
1. 定义DTO (Data Transfer Object)
2. 创建Service业务逻辑
3. 创建Controller路由
4. 添加Swagger文档
5. 编写单元测试

### 数据库迁移
```bash
# 生成新迁移
npm run migration:generate -- -n MigrationName

# 运行迁移
npm run migration:run

# 回滚迁移
npm run migration:revert
```

---

## 📖 文档索引

- [API文档](http://localhost:3000/api) - Swagger UI
- [数据库设计](docs/database-schema.md)
- [985Proxy API集成说明](docs/985proxy-integration.md)
- [Docker部署指南](docs-archive/2025-11-06/DOCKER_DEPLOYMENT_GUIDE.md)
- [测试指南](docs-archive/2025-11-06/README-测试指南.md)
- [历史交付报告](docs-archive/2025-11-06/)

---

## 🐛 已知问题

### 高优先级
1. ~~管理后台API返回500错误~~ - ✅ 已修复 (2025-11-06)
2. ~~静态IP列表字段缺失~~ - ✅ 已修复 (2025-11-06)
3. **流量统计需要集成985Proxy API** - 🚧 待实现
4. **事件日志筛选功能** - 🔍 需要调试

### 中等优先级
5. 订单状态轮询机制 - 📋 已规划
6. 价格显示一致性 - 📋 已规划

---

## 📝 更新日志

### [v1.0.0] - 2025-11-06

#### 新增
- 完整的用户认证和授权系统
- 静态住宅代理购买和管理
- 985Proxy API完整集成
- 管理后台功能
- 账单和订单系统

#### 修复
- 修复管理后台统计API错误
- 修复静态IP列表数据字段缺失
- 修复前端ECharts PieChart导入错误
- 修复auto_renew字段名错误

#### 优化
- 整理项目文件结构
- 创建文档归档目录
- 优化Git提交历史

---

## 🤝 贡献指南

1. Fork本项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启Pull Request

---

## 📄 许可证

本项目采用MIT许可证 - 详见[LICENSE](LICENSE)文件

---

## 💬 联系方式

- GitHub: [https://github.com/lubei0612/proxyhub](https://github.com/lubei0612/proxyhub)
- Issues: [https://github.com/lubei0612/proxyhub/issues](https://github.com/lubei0612/proxyhub/issues)

---

## 🙏 致谢

- [NestJS](https://nestjs.com/) - 强大的Node.js框架
- [Vue.js](https://vuejs.org/) - 渐进式JavaScript框架
- [Element Plus](https://element-plus.org/) - Vue 3 UI组件库
- [985Proxy](https://www.985proxy.com/) - 代理服务提供商

---

**最后更新**: 2025-11-06  
**项目状态**: 🚧 积极开发中

