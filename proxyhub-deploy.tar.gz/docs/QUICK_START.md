# 🚀 ProxyHub 快速启动指南

## 📋 前置要求检查

在开始之前，请确保已安装：
- ✅ Node.js 18+ (`node --version`)
- ✅ Docker (`docker --version`)
- ✅ Docker Compose (`docker-compose --version`)

## 🎯 快速启动步骤

### 方法1: 使用批处理文件（推荐）

1. **启动数据库和所有服务**
```bash
.\start-all.bat
```

这将自动：
- 启动 PostgreSQL 和 Redis
- 启动后端服务 (http://localhost:3000)
- 启动前端服务 (http://localhost:8080)

### 方法2: 手动启动（如果方法1失败）

#### 步骤1: 启动数据库
```bash
docker-compose up -d postgres redis
```

#### 步骤2: 启动后端（新终端窗口1）
```bash
cd backend
npm run start:dev
```

#### 步骤3: 启动前端（新终端窗口2）
```bash
cd frontend
npm run dev
```

## 🧪 测试功能

### 1. 打开浏览器
访问: **http://localhost:8080**

### 2. 测试账户登录

#### 普通用户测试
```
邮箱：test@test.com
密码：test123456
余额：$1000
```

#### 管理员测试
```
邮箱：admin@proxy.com
密码：admin123456
```

### 3. 功能测试清单

#### 用户端功能测试 (/dashboard)
- [ ] **登录系统** - 使用test@test.com登录
- [ ] **查看仪表盘** - 检查数据概览和图表
- [ ] **购买静态IP** - 前往"静态代理" > "购买IP"
  - 选择国家：美国
  - 选择地区：纽约
  - 数量：1个
  - 时长：1个月
  - 点击"立即购买"
- [ ] **管理静态IP** - 查看已购买的IP列表
  - 测试"复制IP"功能
  - 测试"自动续费"开关
  - 测试"添加备注"功能
- [ ] **购买动态代理** - 前往"动态代理" > "购买流量"
  - 选择套餐
  - 确认购买
- [ ] **管理动态代理** - 查看流量统计和使用记录
- [ ] **提交充值申请** - 前往"充值"页面
  - 选择充值方式
  - 输入金额
  - 提交申请
- [ ] **查看订单** - 检查订单列表和详情
- [ ] **查看交易记录** - 检查交易历史
- [ ] **账户中心** - 前往"账户中心"
  - 修改个人信息
  - 生成API Key
  - 修改密码

#### 管理后台功能测试 (/admin-portal)
1. **访问管理后台登录页**
   ```
   http://localhost:8080/admin-portal/login
   ```

2. **使用管理员账户登录**
   ```
   邮箱：admin@proxy.com
   密码：admin123456
   ```

3. **测试管理功能**
- [ ] **数据统计** - 查看系统概览
  - 用户数量
  - 代理IP数量
  - 订单统计
  - 收入统计
- [ ] **用户管理** - 前往"用户管理"
  - 查看用户列表
  - 编辑用户信息
  - 测试封禁/解禁功能
- [ ] **充值审核** - 前往"充值审核"
  - 查看待审核充值
  - 测试通过/拒绝功能
- [ ] **系统设置** - 前往"系统设置"
  - 修改系统参数
  - 保存设置

## 🔍 调试技巧

### 检查服务器状态

#### 检查端口是否在监听
```bash
# Windows
netstat -ano | findstr :8080
netstat -ano | findstr :3000

# Linux/Mac
lsof -i :8080
lsof -i :3000
```

#### 检查Docker容器状态
```bash
docker-compose ps
```

应该看到：
```
proxyhub-postgres    running    0.0.0.0:5432->5432/tcp
proxyhub-redis       running    0.0.0.0:6379->6379/tcp
```

### 查看日志

#### 后端日志
查看终端输出，应该看到：
```
[Nest] ... LOG [NestFactory] Starting Nest application...
[Nest] ... LOG [InstanceLoader] AppModule dependencies initialized
[Nest] ... LOG [RoutesResolver] Mapped {/api/v1/auth/login, POST} route
[Nest] ... LOG [NestApplication] Nest application successfully started
```

#### 前端日志
查看终端输出，应该看到：
```
VITE v5.x.x ready in xxx ms
➜  Local:   http://localhost:8080/
➜  Network: use --host to expose
```

### 常见问题解决

#### 问题1: 端口被占用
```bash
# 查找占用端口的进程
netstat -ano | findstr :8080

# 结束进程（替换PID为实际进程ID）
taskkill /PID <PID> /F
```

#### 问题2: npm脚本无法运行
```powershell
# 设置PowerShell执行策略
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

#### 问题3: 数据库连接失败
```bash
# 重启数据库容器
docker-compose restart postgres

# 检查数据库日志
docker-compose logs postgres
```

#### 问题4: 前端无法连接后端
检查 `frontend/vite.config.ts` 中的代理配置：
```typescript
server: {
  proxy: {
    '/api': {
      target: 'http://localhost:3000',
      changeOrigin: true,
    }
  }
}
```

## 📱 浏览器开发者工具调试

### 打开开发者工具
- Chrome/Edge: 按 `F12` 或 `Ctrl+Shift+I`
- 切换到"Console"标签查看日志
- 切换到"Network"标签查看API请求

### 需要检查的内容

#### Console标签
✅ 应该看到：
```
[Vue] Application mounted
```

❌ 不应该看到：
- 红色错误信息
- API请求失败
- 组件加载错误

#### Network标签
测试登录时应该看到：
```
POST /api/v1/auth/login
Status: 200 OK
Response: { success: true, data: { access_token: "...", user: {...} } }
```

## 🎉 启动成功标志

当你看到以下内容时，说明启动成功：

1. ✅ 数据库容器正在运行
```bash
docker ps
# 应该看到 proxyhub-postgres 和 proxyhub-redis
```

2. ✅ 后端服务器启动
```
[Nest] LOG [NestApplication] Nest application successfully started
```

3. ✅ 前端服务器启动
```
➜  Local:   http://localhost:8080/
```

4. ✅ 浏览器可以访问
- 打开 http://localhost:8080
- 看到登录页面
- Console没有错误

## 🆘 需要帮助？

如果遇到问题，请检查：
1. 所有前置要求是否满足
2. 端口是否被占用
3. Docker容器是否正常运行
4. 网络连接是否正常
5. 浏览器Console和Network标签的错误信息

---

**祝您测试顺利！** 🚀

