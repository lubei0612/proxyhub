# ⚠️ Docker网络问题 - 完整解决方案

## 🔍 问题诊断

您遇到的错误：
```
dial tcp 157.240.17.36:443: connectex: A connection attempt failed
```

**原因**：Docker无法连接到Docker Hub下载镜像（网络连接问题）

---

## 🚀 解决方案1：配置Docker镜像加速器（推荐）⭐

### 步骤1：配置Docker

1. **右键点击桌面Docker图标**
2. 选择 **Settings**（设置）
3. 选择 **Docker Engine**
4. 在JSON配置中找到 `registry-mirrors`，添加国内镜像：

```json
{
  "registry-mirrors": [
    "https://docker.1ms.run",
    "https://docker.anyhub.us.kg",
    "https://dockerhub.icu"
  ]
}
```

5. 点击 **Apply & Restart**
6. 等待Docker重启（约30秒）

### 步骤2：重新构建

配置完成后，运行：
```bash
.\快速修复-重新构建.bat
```

---

## 🚀 解决方案2：使用本地开发环境（更快）⭐⭐⭐

**不使用Docker，直接本地运行，速度更快！**

### 前提条件
- Node.js 18+ 已安装
- PostgreSQL 15+ 已安装（或使用Docker只启动数据库）

### 步骤1：启动数据库（使用Docker）

```bash
# 只启动PostgreSQL和Redis
docker-compose up postgres redis -d
```

### 步骤2：启动后端

```powershell
# 进入后端目录
cd backend

# 安装依赖
npm install

# 创建.env文件
copy .env.example .env

# 初始化数据库
npm run seed

# 启动后端（开发模式）
npm run start:dev
```

### 步骤3：启动前端（新终端窗口）

```powershell
# 进入前端目录
cd frontend

# 安装依赖
npm install

# 启动前端（开发模式）
npm run dev
```

### 步骤4：访问应用

- **前端**：http://localhost:5173
- **后端API**：http://localhost:3000/api/v1
- **API文档**：http://localhost:3000/api/v1/docs

**测试账号**：
- 用户：user@example.com / password123
- 管理员：admin@example.com / admin123

---

## 🚀 解决方案3：使用已构建的镜像

如果您有备用服务器或VPN，可以：

1. 在有良好网络的环境构建镜像
2. 导出镜像：
```bash
docker save proxyhub-backend:latest -o proxyhub-backend.tar
docker save proxyhub-frontend:latest -o proxyhub-frontend.tar
```

3. 在本地导入：
```bash
docker load -i proxyhub-backend.tar
docker load -i proxyhub-frontend.tar
```

---

## 📊 三种方案对比

| 方案 | 优点 | 缺点 | 推荐度 |
|------|------|------|--------|
| 方案1：Docker镜像加速器 | 配置一次永久生效 | 需要配置Docker | ⭐⭐⭐⭐ |
| 方案2：本地开发环境 | 启动快、调试方便 | 需要手动管理服务 | ⭐⭐⭐⭐⭐ |
| 方案3：镜像导入 | 不依赖网络 | 需要其他环境支持 | ⭐⭐ |

---

## 💡 推荐方案

**我强烈推荐使用方案2：本地开发环境**

原因：
1. ✅ **启动速度快** - 不需要Docker构建，直接启动
2. ✅ **热重载** - 代码修改后自动刷新
3. ✅ **调试方便** - 可以直接在IDE中调试
4. ✅ **资源占用少** - 不需要运行完整的Docker容器
5. ✅ **不受网络限制** - 已经下载了所有依赖

### 详细步骤（方案2）

#### 第一步：启动数据库

```bash
# 只启动PostgreSQL和Redis（约10秒）
docker-compose up postgres redis -d

# 检查状态
docker-compose ps
```

应该看到：
```
proxyhub-postgres    Up (healthy)
proxyhub-redis       Up (healthy)
```

#### 第二步：配置后端

```powershell
# 进入后端目录
cd D:\Users\Desktop\proxyhub\backend

# 检查.env文件（如果不存在则创建）
if (!(Test-Path .env)) { Copy-Item docs\ENV_TEMPLATE.txt .env }

# 安装依赖（如果还没安装）
npm install

# 初始化测试数据
npm run seed

# 可选：运行扩展测试数据
npm run seed:extended
```

#### 第三步：启动后端

```powershell
# 在backend目录运行
npm run start:dev
```

等待看到：
```
[Nest] Application successfully started
[Nest] Listening on port 3000
```

#### 第四步：启动前端（新PowerShell窗口）

```powershell
# 进入前端目录
cd D:\Users\Desktop\proxyhub\frontend

# 安装依赖（如果还没安装）
npm install

# 启动开发服务器
npm run dev
```

等待看到：
```
VITE v5.x.x  ready in xxx ms

➜  Local:   http://localhost:5173/
➜  Network: use --host to expose
```

#### 第五步：访问应用

打开浏览器访问：**http://localhost:5173**

登录账号：
- **用户**：user@example.com / password123
- **管理员**：admin@example.com / admin123

---

## 🔧 常见问题

### Q1: 端口被占用

**后端端口3000被占用**：
```powershell
# 查找占用端口的进程
netstat -ano | findstr :3000

# 结束进程（替换<PID>为实际进程ID）
taskkill /F /PID <PID>
```

**前端端口5173被占用**：
Vite会自动尝试下一个可用端口（5174, 5175...）

### Q2: 数据库连接失败

检查PostgreSQL是否运行：
```bash
docker-compose ps postgres
```

如果状态不是 `Up (healthy)`，重启：
```bash
docker-compose restart postgres
```

### Q3: npm install 失败

使用国内镜像：
```bash
npm config set registry https://registry.npmmirror.com
npm install
```

### Q4: 前端白屏

1. 清除浏览器缓存（Ctrl+Shift+Delete）
2. 强制刷新（Ctrl+Shift+R）
3. 检查浏览器控制台（F12）是否有错误

---

## ✅ 验收测试

使用本地环境启动后，测试：

- [ ] 登录功能
- [ ] 语言切换（右上角地球图标）
- [ ] 仪表盘图表
- [ ] 静态IP选购
- [ ] 静态IP管理
- [ ] 钱包充值
- [ ] 管理后台（admin@example.com）

---

## 🎯 生产环境部署

本地测试通过后，部署到腾讯云时：
1. 在腾讯云服务器上配置Docker镜像加速器（方案1）
2. 或直接在服务器上使用本地环境运行（方案2 + PM2进程管理）

---

## 📞 需要帮助？

如果还有问题，请提供：
1. Docker版本：`docker --version`
2. Node.js版本：`node --version`
3. 错误截图或日志

---

**推荐立即使用方案2：本地开发环境！** 🚀

