# ProxyHub UI 设计参考指南

## 🎨 UI设计理念

本项目的UI设计灵感来自**985Proxy**，采用现代化、简洁、专业的风格。

---

## 📐 核心设计原则

### 1. 颜色方案

#### 主色调（用户界面）
```scss
// 浅色主题（白色背景）
$primary-color: #409EFF;        // Element Plus 蓝色
$bg-white: #ffffff;
$bg-light: #f5f7fa;
$text-primary: #303133;
$text-secondary: #606266;
$border-color: #e4e7ed;

// 卡片样式
.el-card {
  background: #ffffff;
  border: 1px solid #e4e7ed;
  border-radius: 8px;
  margin-bottom: 16px;
}
```

#### 深色方案（管理后台 - 如果需要）
```scss
// 深蓝黑主题
$admin-bg: #001529;
$admin-card-bg: rgba(255, 255, 255, 0.05);
$admin-theme-color: #409EFF;
```

---

## 🖼️ 关键页面设计

### 1. 静态代理购买页面（StaticBuy.vue）

**布局结构**：
```
┌─────────────────────────────────────────────────────┐
│ Channel Name Input Card                              │
├─────────────────────────────────────────────────────┤
│ IP Type Card (普通IP / 原生IP)                       │
├─────────────────────────────────────────────────────┤
│ IP Configuration Card                                │
│  - Business Scenario Selector                        │
│  - Region Tabs (欧洲/美洲/亚洲/大洋洲)                │
│  - Country Tabs (带国旗)                             │
├─────────────────────────────────────────────────────┤
│ Purchase Duration Card (30/60/90/180天)             │
├─────────────────────────────────────────────────────┤
│ ┌───────────────────────┬───────────────────────┐  │
│ │ IP Pool Grid          │ Payment Panel         │  │
│ │ (Country Cards)       │ (Right Fixed)         │  │
│ │ - 国旗图标             │ - Cart Items          │  │
│ │ - 国家名称             │ - Total Price         │  │
│ │ - 库存数量             │ - Balance             │  │
│ │ - 价格                │ - Purchase Button     │  │
│ │ - 数量选择器          │ - Clear Cart Button   │  │
│ └───────────────────────┴───────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

**关键特性**：
- ✅ 浅色系背景（#f5f7fa）
- ✅ 白色卡片（#ffffff）
- ✅ 圆角8px
- ✅ 国旗图标使用 `country-flag-icons` 库（SVG格式）
- ✅ 左右分栏布局（IP池 + 支付面板）
- ✅ 响应式设计（小屏幕变为上下布局）

**CSS关键样式**：
```scss
.static-buy-985 {
  padding: 20px;
  background-color: #f5f7fa;
  min-height: calc(100vh - 60px);

  .channel-card,
  .ip-type-card,
  .config-card,
  .duration-card {
    margin-bottom: 16px;
    background: #ffffff;
    border-radius: 8px;
    border: 1px solid #e4e7ed;
  }

  .main-content {
    display: flex;
    gap: 20px;
    align-items: flex-start;

    .ip-pool-section {
      flex: 1;
      background: #ffffff;
      padding: 20px;
      border-radius: 8px;

      .country-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
        gap: 16px;
      }
    }

    .payment-section {
      width: 360px;
      flex-shrink: 0;
    }
  }
}
```

---

### 2. 静态代理管理页面（StaticManage.vue）

**布局结构**：
```
┌─────────────────────────────────────────────────────┐
│ Page Header                                          │
│  - 标题 + 批量操作按钮（批量导出、批量续费）          │
├─────────────────────────────────────────────────────┤
│ Filter Card                                          │
│  - IP搜索 | 国家筛选 | IP类型筛选 | 搜索/重置按钮    │
├─────────────────────────────────────────────────────┤
│ Data Table Card                                      │
│  ┌────┬──────────────┬──────────┬──────┬─────────┐ │
│  │ ☑  │ IP:Port:     │ 国家/城市│ 类型 │ 到期时间│ │
│  │    │ User:Pass    │ (带国旗) │      │ (状态)  │ │
│  │    │ [复制按钮]   │          │      │ 释放时间│ │
│  ├────┼──────────────┼──────────┼──────┼─────────┤ │
│  │ ☑  │ ...          │ ...      │ ...  │ ...     │ │
│  └────┴──────────────┴──────────┴──────┴─────────┘ │
└─────────────────────────────────────────────────────┘
```

**关键特性**：
- ✅ 浅色系主题（与StaticBuy一致）
- ✅ 表格选择复选框
- ✅ 国旗图标显示
- ✅ IP格式：`IP:端口:账号:密码`（带复制按钮）
- ✅ 到期时间状态标签（绿色/黄色/红色）

---

### 3. 支付详情面板（PaymentPanel.vue）

**布局结构**：
```
┌─────────────────────────────────┐
│ Payment Details          [清空] │
├─────────────────────────────────┤
│ Cart Items:                     │
│ ┌─────────────────────────────┐ │
│ │ 🇺🇸 美国 - 纽约              │ │
│ │ Normal IP × 2               │ │
│ │ $10.00                      │ │
│ │ [数量选择器] [删除]          │ │
│ ├─────────────────────────────┤ │
│ │ 🇬🇧 英国 - 伦敦              │ │
│ │ Native IP × 1               │ │
│ │ $8.00                       │ │
│ │ [数量选择器] [删除]          │ │
│ └─────────────────────────────┘ │
├─────────────────────────────────┤
│ Total Quantity: 3 IPs           │
│ Total Price: $18.00             │
│ Current Balance: $100.50        │
├─────────────────────────────────┤
│ [确认购买按钮 - 全宽绿色]       │
└─────────────────────────────────┘
```

**关键特性**：
- ✅ 固定宽度360px
- ✅ 右侧固定位置
- ✅ 显示购物车商品列表
- ✅ 实时计算总价
- ✅ 显示当前余额
- ✅ 余额不足时禁用购买按钮

---

### 4. 国旗图标组件（FlagIcon.vue）

**使用方式**：
```vue
<FlagIcon country-code="US" :size="20" />
<FlagIcon country-code="GB" :size="24" squared />
```

**技术实现**：
- 使用 `country-flag-icons` npm包（SVG格式）
- 支持所有ISO 3166-1 alpha-2国家代码
- 支持自定义尺寸
- 支持方形/矩形比例
- 加载失败时显示国家代码文本后备

---

## 🎨 通用样式变量

创建 `frontend/src/assets/styles/variables.scss`：

```scss
// Colors
$primary-color: #409EFF;
$success-color: #67C23A;
$warning-color: #E6A23C;
$danger-color: #F56C6C;
$info-color: #909399;

// Background
$bg-white: #ffffff;
$bg-light: #f5f7fa;
$bg-lighter: #fafafa;

// Text
$text-primary: #303133;
$text-regular: #606266;
$text-secondary: #909399;
$text-placeholder: #C0C4CC;

// Border
$border-color: #dcdfe6;
$border-color-light: #e4e7ed;
$border-color-lighter: #ebeef5;

// Layout
$card-border-radius: 8px;
$card-padding: 20px;
$card-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
$card-shadow-hover: 0 4px 20px 0 rgba(0, 0, 0, 0.15);

// Font
$font-size-xl: 20px;
$font-size-large: 18px;
$font-size-medium: 16px;
$font-size-base: 14px;
$font-size-small: 13px;
$font-size-xs: 12px;

// Transition
$transition-base: all 0.3s ease;
```

---

## 📦 组件库选择

### Element Plus 2.5+

**主要使用的组件**：
- `el-card` - 卡片容器
- `el-input` - 输入框
- `el-button` - 按钮
- `el-radio-group` / `el-radio-button` - 单选按钮组
- `el-select` - 下拉选择
- `el-table` - 数据表格
- `el-tag` - 标签
- `el-icon` - 图标
- `el-message` - 消息提示
- `el-dialog` - 对话框
- `el-form` - 表单

**自定义主题**：
```typescript
// vite.config.ts
export default defineConfig({
  plugins: [
    vue(),
    Components({
      resolvers: [
        ElementPlusResolver({
          importStyle: 'sass',
        }),
      ],
    }),
  ],
})
```

---

## 🏗️ 布局组件

### DashboardLayout.vue

**结构**：
```
┌─────────────────────────────────────┐
│ Top Navigation Bar                  │
│ Logo | Menu | User | Language       │
├─────────────────────────────────────┤
│                                     │
│ <router-view /> (Page Content)      │
│                                     │
└─────────────────────────────────────┘
```

### AdminLayout.vue（管理后台）

**结构**：
```
┌───────┬─────────────────────────────┐
│       │ Top Bar                     │
│ Side  ├─────────────────────────────┤
│ Menu  │                             │
│       │ <router-view />             │
│ - 用户│ (Admin Content)             │
│ - 充值│                             │
│ - 订单│                             │
│ - IP  │                             │
│ - 统计│                             │
│ - 设置│                             │
└───────┴─────────────────────────────┘
```

---

## 📱 响应式设计

### 断点定义

```scss
// Mobile
@media (max-width: 768px) {
  .main-content {
    flex-direction: column;
    
    .payment-section {
      width: 100%;
    }
  }
}

// Tablet
@media (max-width: 1200px) {
  .country-grid {
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  }
}

// Desktop
@media (min-width: 1201px) {
  .country-grid {
    grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  }
}
```

---

## 🎯 UI实现优先级

### 高优先级（核心界面）
1. ✅ 静态代理购买页面（StaticBuy.vue）
2. ✅ 静态代理管理页面（StaticManage.vue）
3. ✅ 支付详情面板（PaymentPanel.vue）
4. ✅ 国旗图标组件（FlagIcon.vue）
5. ✅ 用户仪表盘（Dashboard.vue）

### 中优先级
6. 动态代理购买页面（DynamicBuy.vue）
7. 充值页面（Recharge.vue）
8. 订单页面（Orders.vue）
9. 交易记录页面（Transactions.vue）

### 低优先级
10. 管理后台各页面（Admin/*.vue）

---

## 🔧 使用此UI参考的步骤

1. **阅读本文档**，了解整体设计理念

2. **查看UI组件文件**：
   - `UI-REFERENCE/components/` - 关键组件代码
   - `UI-REFERENCE/views/` - 关键页面代码
   - `UI-REFERENCE/styles/` - 样式变量

3. **与AI对话时引用**：
   ```
   "请根据 UI-REFERENCE/UI_DESIGN_GUIDE.md 的设计规范，
   实现 StaticBuy.vue 页面。
   参考 UI-REFERENCE/views/StaticBuy.vue 的布局和样式。"
   ```

---

**版本**: v1.0  
**创建日期**: 2025-10-31  
**设计师**: ProxyHub Team

