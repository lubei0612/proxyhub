# ProxyHub 快速API测试指南

**目的**: 快速验证所有前后端API对接和路由配置  
**时间**: 30-45分钟  
**工具**: Chrome浏览器 + DevTools (F12)  

---

## 🚀 启动服务

### 方法1: 使用bat脚本（推荐）
```
双击运行项目根目录的: 启动ProxyHub测试服务.bat
```

### 方法2: 手动启动
```bash
# 终端1
cd backend
npm run start:dev

# 终端2
cd frontend
npm run dev
```

---

## ✅ 核心测试流程

### 1. 用户端测试（20分钟）

#### 1.1 登录
```
访问: http://localhost:8080/login
账户: user@example.com / user123
```

**验证**: 
- [ ] DevTools Network: `POST /api/v1/auth/login` → 200
- [ ] 跳转到仪表盘
- [ ] 导航栏显示余额

---

#### 1.2 购买普通IP
```
路径: 静态住宅 → 静态住宅选购
操作: 
  1. 选择"普通"IP
  2. 选择日本Tokyo，数量1，30天
  3. 验证价格: $10/月
  4. 提交订单
```

**DevTools关键验证**:
```
Network → 找到这3个请求:

1. POST /api/v1/price/calculate
   Status: 201 ✅
   Request: {productType: "static-residential", ...}
   Response: {breakdown: [{location: "JP/Tokyo", unitPrice: 10}]}

2. POST /api/v1/proxy/static/purchase  
   Status: 200/201 ✅
   Request: {items: [{country: "JP", city: "Tokyo"}], ...}

3. GET /api/v1/users/profile
   Response: {balance: (原余额 - 10)}
```

**页面验证**:
- [ ] 价格显示$10/月
- [ ] 订单提交成功
- [ ] 余额减少$10
- [ ] 静态住宅管理显示新IP

---

#### 1.3 购买原生IP
```
操作:
  1. 选择"原生"IP
  2. 选择美国LA，数量1，30天
  3. 验证价格: $10/月
  4. 提交订单
```

**DevTools关键验证**:
```
Network → POST /api/v1/price/calculate
  Request: {productType: "static-residential-native", ...}
  Status: 201 ✅ (不再404!)
  Response: {breakdown: [...]}
```

**验证**: 
- [ ] 原生IP API不返回404
- [ ] 价格显示$10/月
- [ ] 购买成功，余额减少

---

#### 1.4 充值申请
```
路径: 钱包充值
操作:
  金额: 100
  支付方式: 支付宝
  交易单号: TEST001
  提交
```

**DevTools验证**:
```
Network → POST /api/v1/billing/recharge
  Status: 200/201 ✅
  Response: {id: 1, status: "pending"}
```

**验证**:
- [ ] 提交成功
- [ ] 充值记录显示"待审核"

---

#### 1.5 查看数据
```
检查这些页面数据是否正确:
  • 静态住宅管理: 显示2个IP
  • 订单记录: 显示2个订单
  • 交易明细: 显示2笔支出
```

**验证**:
- [ ] 所有列表正确显示
- [ ] 数据一致

---

### 2. 管理端测试（15分钟）

#### 2.1 管理员登录
```
访问: http://localhost:8080/admin/login
账户: admin@example.com / admin123
```

**验证**:
- [ ] DevTools: `POST /api/v1/auth/admin-login` → 200
- [ ] 跳转到管理后台

---

#### 2.2 查看用户订单
```
路径: 订单管理
```

**DevTools验证**:
```
Network → GET /api/v1/orders/admin/all
  Status: 200 ✅
  Response: {data: [...], total: >= 2}
```

**关键验证**:
- [ ] **显示用户购买的2个订单**
- [ ] 包含用户信息
- [ ] 金额正确

---

#### 2.3 充值审核
```
路径: 充值审核
操作: 找到用户的充值申请，点击"批准"
```

**DevTools验证**:
```
Network → 依次:
1. GET /api/v1/billing/admin/recharges
   Response: [{id: 1, status: "pending", amount: 100}]

2. PUT /api/v1/billing/recharge/1/approve
   Status: 200 ✅
```

**验证**:
- [ ] 批准成功
- [ ] 状态更新为"已批准"

---

#### 2.4 价格覆盖管理
```
路径: 价格管理 → 价格覆盖管理
```

**DevTools验证**:
```
Network → GET /api/v1/price/ip-pool
  Status: 200 ✅
  Response: {data: [...26个地区], total: 26}
```

**验证**:
- [ ] 显示26个地区
- [ ] 日本Tokyo显示$10覆盖价格
- [ ] 可以修改价格

---

### 3. 数据流验证（10分钟）

#### 3.1 管理员修改价格 → 用户看到

**管理员操作**:
```
价格覆盖管理 → 韩国Seoul → 修改为$15 → 保存
```

**DevTools**:
```
POST /api/v1/price/overrides/batch
  Request: {updates: [{country: "KR", city: "Seoul", overridePrice: 15}]}
  Status: 200 ✅
```

**切换到用户**:
```
静态住宅选购 → 普通IP → 查看韩国Seoul
```

**DevTools**:
```
POST /api/v1/price/calculate
  Response: {breakdown: [{location: "KR/Seoul", unitPrice: 15}]}
```

**验证**:
- [ ] 用户看到新价格$15/月

---

#### 3.2 充值批准 → 用户余额更新

**切换回用户账户**:
```
查看导航栏余额
```

**验证**:
- [ ] 余额增加$100（充值已批准）
- [ ] 充值记录状态为"已批准"
- [ ] 交易明细显示充值记录

---

## 📊 快速检查清单

### 用户端API
```
✅ POST   /api/v1/auth/login              - 登录
✅ POST   /api/v1/price/calculate         - 价格计算（普通）
✅ POST   /api/v1/price/calculate         - 价格计算（原生，不404）
✅ POST   /api/v1/proxy/static/purchase   - 购买代理
✅ GET    /api/v1/proxy/static/list       - 代理列表
✅ GET    /api/v1/orders                  - 订单列表
✅ GET    /api/v1/billing/transactions    - 交易明细
✅ POST   /api/v1/billing/recharge        - 充值申请
✅ GET    /api/v1/users/profile           - 用户信息（余额更新）
```

### 管理端API
```
✅ POST   /api/v1/auth/admin-login        - 管理员登录
✅ GET    /api/v1/orders/admin/all        - 所有订单
✅ GET    /api/v1/billing/admin/recharges - 充值审核列表
✅ PUT    /api/v1/billing/recharge/:id/approve - 批准充值
✅ GET    /api/v1/price/ip-pool           - IP池列表
✅ POST   /api/v1/price/overrides/batch   - 批量价格覆盖
✅ GET    /api/v1/admin/users             - 用户列表
```

### 数据流验证
```
✅ 用户购买 → 管理员可见订单
✅ 管理员批准充值 → 用户余额更新
✅ 管理员修改价格 → 用户看到新价格
```

**总计**: 16个核心API + 3个数据流

---

## 🎯 成功标准

**所有测试通过，如果**:
- [ ] 所有API请求返回200/201
- [ ] 用户操作在管理后台可见
- [ ] 余额变化正确同步
- [ ] 价格覆盖正确应用
- [ ] 订单数据完整一致

**测试完成！** ✅

---

## 📝 问题记录

| API | 状态码 | 问题 | 严重性 |
|-----|--------|------|--------|
| | | | |

---

**详细测试指南**: `docs/spec-workflow/全面API路由测试/测试执行指南.md`  
**问题反馈**: 记录到问题记录表


